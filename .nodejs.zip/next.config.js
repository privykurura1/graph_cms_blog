export const reactStrictMode = true;
