"use strict";
(() => {
var exports = {};
exports.id = "pages/api/comments";
exports.ids = ["pages/api/comments"];
exports.modules = {

/***/ "./pages/api/comments.js":
/*!*******************************!*\
  !*** ./pages/api/comments.js ***!
  \*******************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ asynchandler)
/* harmony export */ });
/* harmony import */ var graphql_request__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! graphql-request */ "graphql-request");
/* harmony import */ var graphql_request__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(graphql_request__WEBPACK_IMPORTED_MODULE_0__);

const graphqlAPI = "https://api-us-east-1-shared-usea1-02.hygraph.com/v2/clleq4o004g5i01t9dr8ha60a/master";
/** *************************************************************
* Any file inside the folder pages/api is mapped to /api/* and  *
* will be treated as an API endpoint instead of a page.         *
*************************************************************** */
// export a default function for API route to work

async function asynchandler(req, res) {
  const graphQLClient = new graphql_request__WEBPACK_IMPORTED_MODULE_0__.GraphQLClient(graphqlAPI, {
    headers: {
      authorization: `Bearer ${process.env.GRAPHCMS_TOKEN}`
    }
  });
  const query = graphql_request__WEBPACK_IMPORTED_MODULE_0__.gql`
    mutation CreateComment($name: String!, $email: String!, $comment: String!, $slug: String!) {
      createComment(data: {name: $name, email: $email, comment: $comment, post: {connect: {slug: $slug}}}) { id }
    }
  `;
  const result = await graphQLClient.request(query, {
    name: req.body.name,
    email: req.body.email,
    comment: req.body.comment,
    slug: req.body.slug
  });
  return res.status(500).send(result);
}

/***/ }),

/***/ "graphql-request":
/*!**********************************!*\
  !*** external "graphql-request" ***!
  \**********************************/
/***/ ((module) => {

module.exports = require("graphql-request");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__("./pages/api/comments.js"));
module.exports = __webpack_exports__;

})();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicGFnZXMvYXBpL2NvbW1lbnRzLmpzIiwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQTtBQUVBLE1BQU1FLFVBQVUsR0FBR0MsdUZBQW5CO0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFFQTs7QUFDZSxlQUFlRyxZQUFmLENBQTRCQyxHQUE1QixFQUFpQ0MsR0FBakMsRUFBc0M7QUFDbkQsUUFBTUMsYUFBYSxHQUFHLElBQUlULDBEQUFKLENBQW1CRSxVQUFuQixFQUFnQztBQUNwRFEsSUFBQUEsT0FBTyxFQUFFO0FBQ1BDLE1BQUFBLGFBQWEsRUFBRyxVQUFTUixPQUFPLENBQUNDLEdBQVIsQ0FBWVEsY0FBZTtBQUQ3QztBQUQyQyxHQUFoQyxDQUF0QjtBQU1BLFFBQU1DLEtBQUssR0FBR1osZ0RBQUk7QUFDcEI7QUFDQTtBQUNBO0FBQ0EsR0FKRTtBQU1BLFFBQU1hLE1BQU0sR0FBRyxNQUFNTCxhQUFhLENBQUNNLE9BQWQsQ0FBc0JGLEtBQXRCLEVBQTZCO0FBQ2hERyxJQUFBQSxJQUFJLEVBQUVULEdBQUcsQ0FBQ1UsSUFBSixDQUFTRCxJQURpQztBQUVoREUsSUFBQUEsS0FBSyxFQUFFWCxHQUFHLENBQUNVLElBQUosQ0FBU0MsS0FGZ0M7QUFHaERDLElBQUFBLE9BQU8sRUFBRVosR0FBRyxDQUFDVSxJQUFKLENBQVNFLE9BSDhCO0FBSWhEQyxJQUFBQSxJQUFJLEVBQUViLEdBQUcsQ0FBQ1UsSUFBSixDQUFTRztBQUppQyxHQUE3QixDQUFyQjtBQU9BLFNBQU9aLEdBQUcsQ0FBQ2EsTUFBSixDQUFXLEdBQVgsRUFBZ0JDLElBQWhCLENBQXFCUixNQUFyQixDQUFQO0FBQ0Q7Ozs7Ozs7Ozs7QUMvQkQiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9ncmFwaGNtcy1ibG9nLy4vcGFnZXMvYXBpL2NvbW1lbnRzLmpzIiwid2VicGFjazovL2dyYXBoY21zLWJsb2cvZXh0ZXJuYWwgXCJncmFwaHFsLXJlcXVlc3RcIiJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBHcmFwaFFMQ2xpZW50LCBncWwgfSBmcm9tICdncmFwaHFsLXJlcXVlc3QnO1xyXG5cclxuY29uc3QgZ3JhcGhxbEFQSSA9IHByb2Nlc3MuZW52Lk5FWFRfUFVCTElDX0dSQVBIQ01TX0VORFBPSU5UO1xyXG5cclxuLyoqICoqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKipcclxuKiBBbnkgZmlsZSBpbnNpZGUgdGhlIGZvbGRlciBwYWdlcy9hcGkgaXMgbWFwcGVkIHRvIC9hcGkvKiBhbmQgICpcclxuKiB3aWxsIGJlIHRyZWF0ZWQgYXMgYW4gQVBJIGVuZHBvaW50IGluc3RlYWQgb2YgYSBwYWdlLiAgICAgICAgICpcclxuKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqICovXHJcblxyXG4vLyBleHBvcnQgYSBkZWZhdWx0IGZ1bmN0aW9uIGZvciBBUEkgcm91dGUgdG8gd29ya1xyXG5leHBvcnQgZGVmYXVsdCBhc3luYyBmdW5jdGlvbiBhc3luY2hhbmRsZXIocmVxLCByZXMpIHtcclxuICBjb25zdCBncmFwaFFMQ2xpZW50ID0gbmV3IEdyYXBoUUxDbGllbnQoKGdyYXBocWxBUEkpLCB7XHJcbiAgICBoZWFkZXJzOiB7XHJcbiAgICAgIGF1dGhvcml6YXRpb246IGBCZWFyZXIgJHtwcm9jZXNzLmVudi5HUkFQSENNU19UT0tFTn1gLFxyXG4gICAgfSxcclxuICB9KTtcclxuXHJcbiAgY29uc3QgcXVlcnkgPSBncWxgXHJcbiAgICBtdXRhdGlvbiBDcmVhdGVDb21tZW50KCRuYW1lOiBTdHJpbmchLCAkZW1haWw6IFN0cmluZyEsICRjb21tZW50OiBTdHJpbmchLCAkc2x1ZzogU3RyaW5nISkge1xyXG4gICAgICBjcmVhdGVDb21tZW50KGRhdGE6IHtuYW1lOiAkbmFtZSwgZW1haWw6ICRlbWFpbCwgY29tbWVudDogJGNvbW1lbnQsIHBvc3Q6IHtjb25uZWN0OiB7c2x1ZzogJHNsdWd9fX0pIHsgaWQgfVxyXG4gICAgfVxyXG4gIGA7XHJcblxyXG4gIGNvbnN0IHJlc3VsdCA9IGF3YWl0IGdyYXBoUUxDbGllbnQucmVxdWVzdChxdWVyeSwge1xyXG4gICAgbmFtZTogcmVxLmJvZHkubmFtZSxcclxuICAgIGVtYWlsOiByZXEuYm9keS5lbWFpbCxcclxuICAgIGNvbW1lbnQ6IHJlcS5ib2R5LmNvbW1lbnQsXHJcbiAgICBzbHVnOiByZXEuYm9keS5zbHVnLFxyXG4gIH0pO1xyXG5cclxuICByZXR1cm4gcmVzLnN0YXR1cyg1MDApLnNlbmQocmVzdWx0KTtcclxufVxyXG4iLCJtb2R1bGUuZXhwb3J0cyA9IHJlcXVpcmUoXCJncmFwaHFsLXJlcXVlc3RcIik7Il0sIm5hbWVzIjpbIkdyYXBoUUxDbGllbnQiLCJncWwiLCJncmFwaHFsQVBJIiwicHJvY2VzcyIsImVudiIsIk5FWFRfUFVCTElDX0dSQVBIQ01TX0VORFBPSU5UIiwiYXN5bmNoYW5kbGVyIiwicmVxIiwicmVzIiwiZ3JhcGhRTENsaWVudCIsImhlYWRlcnMiLCJhdXRob3JpemF0aW9uIiwiR1JBUEhDTVNfVE9LRU4iLCJxdWVyeSIsInJlc3VsdCIsInJlcXVlc3QiLCJuYW1lIiwiYm9keSIsImVtYWlsIiwiY29tbWVudCIsInNsdWciLCJzdGF0dXMiLCJzZW5kIl0sInNvdXJjZVJvb3QiOiIifQ==