"use strict";
self["webpackHotUpdate_N_E"]("pages/_app",{

/***/ "./components/CommentsForm.jsx":
/*!*************************************!*\
  !*** ./components/CommentsForm.jsx ***!
  \*************************************/
/***/ (function(module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony import */ var C_Users_privy_Desktop_project_graphql_blog_node_modules_babel_runtime_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/defineProperty */ "./node_modules/@babel/runtime/helpers/esm/defineProperty.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _services__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../services */ "./services/index.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! react/jsx-dev-runtime */ "./node_modules/react/jsx-dev-runtime.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__);
/* module decorator */ module = __webpack_require__.hmd(module);


var _jsxFileName = "C:\\Users\\privy\\Desktop\\project_graphql_blog\\components\\CommentsForm.jsx",
    _this = undefined,
    _s = $RefreshSig$();

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { (0,C_Users_privy_Desktop_project_graphql_blog_node_modules_babel_runtime_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_0__.default)(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }





var CommentsForm = function CommentsForm(_ref) {
  _s();

  var slug = _ref.slug;

  var _useState = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(true),
      error = _useState[0],
      setError = _useState[1];

  var _useState2 = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(null),
      localStorage = _useState2[0],
      setLocalStorage = _useState2[1];

  var _useState3 = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false),
      showSuccessMessage = _useState3[0],
      setShowSuccessMessage = _useState3[1];

  var _useState4 = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)({
    name: null,
    email: null,
    comment: null,
    storeData: false
  }),
      formData = _useState4[0],
      setFormData = _useState4[1];

  (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(function () {
    setLocalStorage(window.localStorage);
    var initalFormData = {
      name: window.localStorage.getItem('name'),
      email: window.localStorage.getItem('email'),
      storeData: window.localStorage.getItem('name') || window.localStorage.getItem('email')
    };
    setFormData(initalFormData);
  }, []);

  var onInputChange = function onInputChange(e) {
    var target = e.target;

    if (target.type === 'checkbox') {
      setFormData(function (prevState) {
        return _objectSpread(_objectSpread({}, prevState), {}, (0,C_Users_privy_Desktop_project_graphql_blog_node_modules_babel_runtime_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_0__.default)({}, target.name, target.checked));
      });
    } else {
      setFormData(function (prevState) {
        return _objectSpread(_objectSpread({}, prevState), {}, (0,C_Users_privy_Desktop_project_graphql_blog_node_modules_babel_runtime_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_0__.default)({}, target.name, target.value));
      });
    }
  };

  var handlePostSubmission = function handlePostSubmission() {
    setError(false);
    var name = formData.name,
        email = formData.email,
        comment = formData.comment,
        storeData = formData.storeData;

    if (!name || !email || !comment) {
      setError(true);
      return;
    }

    var commentObj = {
      name: name,
      email: email,
      comment: comment,
      slug: slug
    };

    if (storeData) {
      localStorage.setItem('name', name);
      localStorage.setItem('email', email);
    } else {
      localStorage.removeItem('name');
      localStorage.removeItem('email');
    }

    (0,_services__WEBPACK_IMPORTED_MODULE_2__.submitComment)(commentObj).then(function (res) {
      if (res.createComment) {
        if (!storeData) {
          formData.name = '';
          formData.email = '';
        }

        formData.comment = '';
        setFormData(function (prevState) {
          return _objectSpread(_objectSpread({}, prevState), formData);
        });
        setShowSuccessMessage(true);
        setTimeout(function () {
          setShowSuccessMessage(false);
        }, 3000);
      }
    });
  };

  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)("div", {
    className: "bg-white shadow-lg rounded-lg p-8 pb-12 mb-8",
    children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)("h3", {
      className: "text-xl mb-8 font-semibold border-b pb-4",
      children: "Leave a Reply"
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 79,
      columnNumber: 7
    }, _this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)("div", {
      className: "grid grid-cols-1 gap-4 mb-4",
      children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)("textarea", {
        value: formData.comment,
        onChange: onInputChange,
        className: "p-4 outline-none w-full rounded-lg h-40 focus:ring-2 focus:ring-gray-200 bg-gray-100 text-gray-700",
        name: "comment",
        placeholder: "Comment"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 81,
        columnNumber: 9
      }, _this)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 80,
      columnNumber: 7
    }, _this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)("div", {
      className: "grid grid-cols-1 lg:grid-cols-2 gap-4 mb-4",
      children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)("input", {
        type: "text",
        value: formData.name,
        onChange: onInputChange,
        className: "py-2 px-4 outline-none w-full rounded-lg focus:ring-2 focus:ring-gray-200 bg-gray-100 text-gray-700",
        placeholder: "Name",
        name: "name"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 84,
        columnNumber: 9
      }, _this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)("input", {
        type: "email",
        value: formData.email,
        onChange: onInputChange,
        className: "py-2 px-4 outline-none w-full rounded-lg focus:ring-2 focus:ring-gray-200 bg-gray-100 text-gray-700",
        placeholder: "Email",
        name: "email"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 85,
        columnNumber: 9
      }, _this)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 83,
      columnNumber: 7
    }, _this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)("div", {
      className: "grid grid-cols-1 gap-4 mb-4",
      children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)("div", {
        children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)("input", {
          checked: formData.storeData,
          onChange: onInputChange,
          type: "checkbox",
          id: "storeData",
          name: "storeData",
          value: "true"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 89,
          columnNumber: 11
        }, _this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)("label", {
          className: "text-gray-500 cursor-pointer",
          htmlFor: "storeData",
          children: " Save my name, email in this browser for the next time I comment."
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 90,
          columnNumber: 11
        }, _this)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 88,
        columnNumber: 9
      }, _this)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 87,
      columnNumber: 7
    }, _this), error && /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)("p", {
      className: "text-xs text-red-500",
      children: "All fields are mandatory"
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 93,
      columnNumber: 17
    }, _this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)("div", {
      className: "mt-8",
      children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)("button", {
        type: "button",
        onClick: handlePostSubmission,
        className: "transition duration-500 ease hover:bg-indigo-900 inline-block bg-pink-600 text-lg font-medium rounded-full text-white px-8 py-3 cursor-pointer",
        children: "Post Comment"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 95,
        columnNumber: 9
      }, _this), showSuccessMessage && /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)("span", {
        className: "text-xl float-right font-semibold mt-3 text-green-500",
        children: "Comment submitted for review"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 96,
        columnNumber: 32
      }, _this)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 94,
      columnNumber: 7
    }, _this)]
  }, void 0, true, {
    fileName: _jsxFileName,
    lineNumber: 78,
    columnNumber: 5
  }, _this);
};

_s(CommentsForm, "gCEr6lS3yRrSJwzcXby+sHwVdVw=");

_c = CommentsForm;
/* harmony default export */ __webpack_exports__["default"] = (CommentsForm);

var _c;

$RefreshReg$(_c, "CommentsForm");

;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.id);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }


/***/ })

});
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic3RhdGljL3dlYnBhY2svcGFnZXMvX2FwcC5lMmEyODhmMTFmZTA1MjIwMzdmOC5ob3QtdXBkYXRlLmpzIiwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUFBO0FBQ0E7OztBQUVBLElBQU1JLFlBQVksR0FBRyxTQUFmQSxZQUFlLE9BQWM7QUFBQTs7QUFBQSxNQUFYQyxJQUFXLFFBQVhBLElBQVc7O0FBQ2pDLGtCQUEwQkosK0NBQVEsQ0FBQyxJQUFELENBQWxDO0FBQUEsTUFBT0ssS0FBUDtBQUFBLE1BQWNDLFFBQWQ7O0FBQ0EsbUJBQXdDTiwrQ0FBUSxDQUFDLElBQUQsQ0FBaEQ7QUFBQSxNQUFPTyxZQUFQO0FBQUEsTUFBcUJDLGVBQXJCOztBQUNBLG1CQUFvRFIsK0NBQVEsQ0FBQyxLQUFELENBQTVEO0FBQUEsTUFBT1Msa0JBQVA7QUFBQSxNQUEyQkMscUJBQTNCOztBQUNBLG1CQUFnQ1YsK0NBQVEsQ0FBQztBQUFFVyxJQUFBQSxJQUFJLEVBQUUsSUFBUjtBQUFjQyxJQUFBQSxLQUFLLEVBQUUsSUFBckI7QUFBMkJDLElBQUFBLE9BQU8sRUFBRSxJQUFwQztBQUEwQ0MsSUFBQUEsU0FBUyxFQUFFO0FBQXJELEdBQUQsQ0FBeEM7QUFBQSxNQUFPQyxRQUFQO0FBQUEsTUFBaUJDLFdBQWpCOztBQUVBZixFQUFBQSxnREFBUyxDQUFDLFlBQU07QUFDZE8sSUFBQUEsZUFBZSxDQUFDUyxNQUFNLENBQUNWLFlBQVIsQ0FBZjtBQUNBLFFBQU1XLGNBQWMsR0FBRztBQUNyQlAsTUFBQUEsSUFBSSxFQUFFTSxNQUFNLENBQUNWLFlBQVAsQ0FBb0JZLE9BQXBCLENBQTRCLE1BQTVCLENBRGU7QUFFckJQLE1BQUFBLEtBQUssRUFBRUssTUFBTSxDQUFDVixZQUFQLENBQW9CWSxPQUFwQixDQUE0QixPQUE1QixDQUZjO0FBR3JCTCxNQUFBQSxTQUFTLEVBQUVHLE1BQU0sQ0FBQ1YsWUFBUCxDQUFvQlksT0FBcEIsQ0FBNEIsTUFBNUIsS0FBdUNGLE1BQU0sQ0FBQ1YsWUFBUCxDQUFvQlksT0FBcEIsQ0FBNEIsT0FBNUI7QUFIN0IsS0FBdkI7QUFLQUgsSUFBQUEsV0FBVyxDQUFDRSxjQUFELENBQVg7QUFDRCxHQVJRLEVBUU4sRUFSTSxDQUFUOztBQVVBLE1BQU1FLGFBQWEsR0FBRyxTQUFoQkEsYUFBZ0IsQ0FBQ0MsQ0FBRCxFQUFPO0FBQzNCLFFBQVFDLE1BQVIsR0FBbUJELENBQW5CLENBQVFDLE1BQVI7O0FBQ0EsUUFBSUEsTUFBTSxDQUFDQyxJQUFQLEtBQWdCLFVBQXBCLEVBQWdDO0FBQzlCUCxNQUFBQSxXQUFXLENBQUMsVUFBQ1EsU0FBRDtBQUFBLCtDQUNQQSxTQURPLHFKQUVURixNQUFNLENBQUNYLElBRkUsRUFFS1csTUFBTSxDQUFDRyxPQUZaO0FBQUEsT0FBRCxDQUFYO0FBSUQsS0FMRCxNQUtPO0FBQ0xULE1BQUFBLFdBQVcsQ0FBQyxVQUFDUSxTQUFEO0FBQUEsK0NBQ1BBLFNBRE8scUpBRVRGLE1BQU0sQ0FBQ1gsSUFGRSxFQUVLVyxNQUFNLENBQUNJLEtBRlo7QUFBQSxPQUFELENBQVg7QUFJRDtBQUNGLEdBYkQ7O0FBZUEsTUFBTUMsb0JBQW9CLEdBQUcsU0FBdkJBLG9CQUF1QixHQUFNO0FBQ2pDckIsSUFBQUEsUUFBUSxDQUFDLEtBQUQsQ0FBUjtBQUNBLFFBQVFLLElBQVIsR0FBNENJLFFBQTVDLENBQVFKLElBQVI7QUFBQSxRQUFjQyxLQUFkLEdBQTRDRyxRQUE1QyxDQUFjSCxLQUFkO0FBQUEsUUFBcUJDLE9BQXJCLEdBQTRDRSxRQUE1QyxDQUFxQkYsT0FBckI7QUFBQSxRQUE4QkMsU0FBOUIsR0FBNENDLFFBQTVDLENBQThCRCxTQUE5Qjs7QUFDQSxRQUFJLENBQUNILElBQUQsSUFBUyxDQUFDQyxLQUFWLElBQW1CLENBQUNDLE9BQXhCLEVBQWlDO0FBQy9CUCxNQUFBQSxRQUFRLENBQUMsSUFBRCxDQUFSO0FBQ0E7QUFDRDs7QUFDRCxRQUFNc0IsVUFBVSxHQUFHO0FBQ2pCakIsTUFBQUEsSUFBSSxFQUFKQSxJQURpQjtBQUVqQkMsTUFBQUEsS0FBSyxFQUFMQSxLQUZpQjtBQUdqQkMsTUFBQUEsT0FBTyxFQUFQQSxPQUhpQjtBQUlqQlQsTUFBQUEsSUFBSSxFQUFKQTtBQUppQixLQUFuQjs7QUFPQSxRQUFJVSxTQUFKLEVBQWU7QUFDYlAsTUFBQUEsWUFBWSxDQUFDc0IsT0FBYixDQUFxQixNQUFyQixFQUE2QmxCLElBQTdCO0FBQ0FKLE1BQUFBLFlBQVksQ0FBQ3NCLE9BQWIsQ0FBcUIsT0FBckIsRUFBOEJqQixLQUE5QjtBQUNELEtBSEQsTUFHTztBQUNMTCxNQUFBQSxZQUFZLENBQUN1QixVQUFiLENBQXdCLE1BQXhCO0FBQ0F2QixNQUFBQSxZQUFZLENBQUN1QixVQUFiLENBQXdCLE9BQXhCO0FBQ0Q7O0FBRUQ1QixJQUFBQSx3REFBYSxDQUFDMEIsVUFBRCxDQUFiLENBQ0dHLElBREgsQ0FDUSxVQUFDQyxHQUFELEVBQVM7QUFDYixVQUFJQSxHQUFHLENBQUNDLGFBQVIsRUFBdUI7QUFDckIsWUFBSSxDQUFDbkIsU0FBTCxFQUFnQjtBQUNkQyxVQUFBQSxRQUFRLENBQUNKLElBQVQsR0FBZ0IsRUFBaEI7QUFDQUksVUFBQUEsUUFBUSxDQUFDSCxLQUFULEdBQWlCLEVBQWpCO0FBQ0Q7O0FBQ0RHLFFBQUFBLFFBQVEsQ0FBQ0YsT0FBVCxHQUFtQixFQUFuQjtBQUNBRyxRQUFBQSxXQUFXLENBQUMsVUFBQ1EsU0FBRDtBQUFBLGlEQUNQQSxTQURPLEdBRVBULFFBRk87QUFBQSxTQUFELENBQVg7QUFJQUwsUUFBQUEscUJBQXFCLENBQUMsSUFBRCxDQUFyQjtBQUNBd0IsUUFBQUEsVUFBVSxDQUFDLFlBQU07QUFDZnhCLFVBQUFBLHFCQUFxQixDQUFDLEtBQUQsQ0FBckI7QUFDRCxTQUZTLEVBRVAsSUFGTyxDQUFWO0FBR0Q7QUFDRixLQWpCSDtBQWtCRCxHQXhDRDs7QUEwQ0Esc0JBQ0U7QUFBSyxhQUFTLEVBQUMsOENBQWY7QUFBQSw0QkFDRTtBQUFJLGVBQVMsRUFBQywwQ0FBZDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQURGLGVBRUU7QUFBSyxlQUFTLEVBQUMsNkJBQWY7QUFBQSw2QkFDRTtBQUFVLGFBQUssRUFBRUssUUFBUSxDQUFDRixPQUExQjtBQUFtQyxnQkFBUSxFQUFFTyxhQUE3QztBQUE0RCxpQkFBUyxFQUFDLG9HQUF0RTtBQUEySyxZQUFJLEVBQUMsU0FBaEw7QUFBMEwsbUJBQVcsRUFBQztBQUF0TTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUZGLGVBS0U7QUFBSyxlQUFTLEVBQUMsNENBQWY7QUFBQSw4QkFDRTtBQUFPLFlBQUksRUFBQyxNQUFaO0FBQW1CLGFBQUssRUFBRUwsUUFBUSxDQUFDSixJQUFuQztBQUF5QyxnQkFBUSxFQUFFUyxhQUFuRDtBQUFrRSxpQkFBUyxFQUFDLHFHQUE1RTtBQUFrTCxtQkFBVyxFQUFDLE1BQTlMO0FBQXFNLFlBQUksRUFBQztBQUExTTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBREYsZUFFRTtBQUFPLFlBQUksRUFBQyxPQUFaO0FBQW9CLGFBQUssRUFBRUwsUUFBUSxDQUFDSCxLQUFwQztBQUEyQyxnQkFBUSxFQUFFUSxhQUFyRDtBQUFvRSxpQkFBUyxFQUFDLHFHQUE5RTtBQUFvTCxtQkFBVyxFQUFDLE9BQWhNO0FBQXdNLFlBQUksRUFBQztBQUE3TTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBTEYsZUFTRTtBQUFLLGVBQVMsRUFBQyw2QkFBZjtBQUFBLDZCQUNFO0FBQUEsZ0NBQ0U7QUFBTyxpQkFBTyxFQUFFTCxRQUFRLENBQUNELFNBQXpCO0FBQW9DLGtCQUFRLEVBQUVNLGFBQTlDO0FBQTZELGNBQUksRUFBQyxVQUFsRTtBQUE2RSxZQUFFLEVBQUMsV0FBaEY7QUFBNEYsY0FBSSxFQUFDLFdBQWpHO0FBQTZHLGVBQUssRUFBQztBQUFuSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQURGLGVBRUU7QUFBTyxtQkFBUyxFQUFDLDhCQUFqQjtBQUFnRCxpQkFBTyxFQUFDLFdBQXhEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUZGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFURixFQWVHZixLQUFLLGlCQUFJO0FBQUcsZUFBUyxFQUFDLHNCQUFiO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBZlosZUFnQkU7QUFBSyxlQUFTLEVBQUMsTUFBZjtBQUFBLDhCQUNFO0FBQVEsWUFBSSxFQUFDLFFBQWI7QUFBc0IsZUFBTyxFQUFFc0Isb0JBQS9CO0FBQXFELGlCQUFTLEVBQUMsZ0pBQS9EO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBREYsRUFFR2xCLGtCQUFrQixpQkFBSTtBQUFNLGlCQUFTLEVBQUMsdURBQWhCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRnpCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQWhCRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FERjtBQXVCRCxDQWhHRDs7R0FBTU47O0tBQUFBO0FBa0dOLCtEQUFlQSxZQUFmIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vX05fRS8uL2NvbXBvbmVudHMvQ29tbWVudHNGb3JtLmpzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUmVhY3QsIHsgdXNlU3RhdGUsIHVzZUVmZmVjdCB9IGZyb20gJ3JlYWN0JztcclxuaW1wb3J0IHsgc3VibWl0Q29tbWVudCB9IGZyb20gJy4uL3NlcnZpY2VzJztcclxuXHJcbmNvbnN0IENvbW1lbnRzRm9ybSA9ICh7IHNsdWcgfSkgPT4ge1xyXG4gIGNvbnN0IFtlcnJvciwgc2V0RXJyb3JdID0gdXNlU3RhdGUodHJ1ZSk7XHJcbiAgY29uc3QgW2xvY2FsU3RvcmFnZSwgc2V0TG9jYWxTdG9yYWdlXSA9IHVzZVN0YXRlKG51bGwpO1xyXG4gIGNvbnN0IFtzaG93U3VjY2Vzc01lc3NhZ2UsIHNldFNob3dTdWNjZXNzTWVzc2FnZV0gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgY29uc3QgW2Zvcm1EYXRhLCBzZXRGb3JtRGF0YV0gPSB1c2VTdGF0ZSh7IG5hbWU6IG51bGwsIGVtYWlsOiBudWxsLCBjb21tZW50OiBudWxsLCBzdG9yZURhdGE6IGZhbHNlIH0pO1xyXG5cclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgc2V0TG9jYWxTdG9yYWdlKHdpbmRvdy5sb2NhbFN0b3JhZ2UpO1xyXG4gICAgY29uc3QgaW5pdGFsRm9ybURhdGEgPSB7XHJcbiAgICAgIG5hbWU6IHdpbmRvdy5sb2NhbFN0b3JhZ2UuZ2V0SXRlbSgnbmFtZScpLFxyXG4gICAgICBlbWFpbDogd2luZG93LmxvY2FsU3RvcmFnZS5nZXRJdGVtKCdlbWFpbCcpLFxyXG4gICAgICBzdG9yZURhdGE6IHdpbmRvdy5sb2NhbFN0b3JhZ2UuZ2V0SXRlbSgnbmFtZScpIHx8IHdpbmRvdy5sb2NhbFN0b3JhZ2UuZ2V0SXRlbSgnZW1haWwnKSxcclxuICAgIH07XHJcbiAgICBzZXRGb3JtRGF0YShpbml0YWxGb3JtRGF0YSk7XHJcbiAgfSwgW10pO1xyXG5cclxuICBjb25zdCBvbklucHV0Q2hhbmdlID0gKGUpID0+IHtcclxuICAgIGNvbnN0IHsgdGFyZ2V0IH0gPSBlO1xyXG4gICAgaWYgKHRhcmdldC50eXBlID09PSAnY2hlY2tib3gnKSB7XHJcbiAgICAgIHNldEZvcm1EYXRhKChwcmV2U3RhdGUpID0+ICh7XHJcbiAgICAgICAgLi4ucHJldlN0YXRlLFxyXG4gICAgICAgIFt0YXJnZXQubmFtZV06IHRhcmdldC5jaGVja2VkLFxyXG4gICAgICB9KSk7XHJcbiAgICB9IGVsc2Uge1xyXG4gICAgICBzZXRGb3JtRGF0YSgocHJldlN0YXRlKSA9PiAoe1xyXG4gICAgICAgIC4uLnByZXZTdGF0ZSxcclxuICAgICAgICBbdGFyZ2V0Lm5hbWVdOiB0YXJnZXQudmFsdWUsXHJcbiAgICAgIH0pKTtcclxuICAgIH1cclxuICB9O1xyXG5cclxuICBjb25zdCBoYW5kbGVQb3N0U3VibWlzc2lvbiA9ICgpID0+IHtcclxuICAgIHNldEVycm9yKGZhbHNlKTtcclxuICAgIGNvbnN0IHsgbmFtZSwgZW1haWwsIGNvbW1lbnQsIHN0b3JlRGF0YSB9ID0gZm9ybURhdGE7XHJcbiAgICBpZiAoIW5hbWUgfHwgIWVtYWlsIHx8ICFjb21tZW50KSB7XHJcbiAgICAgIHNldEVycm9yKHRydWUpO1xyXG4gICAgICByZXR1cm47XHJcbiAgICB9XHJcbiAgICBjb25zdCBjb21tZW50T2JqID0ge1xyXG4gICAgICBuYW1lLFxyXG4gICAgICBlbWFpbCxcclxuICAgICAgY29tbWVudCxcclxuICAgICAgc2x1ZyxcclxuICAgIH07XHJcblxyXG4gICAgaWYgKHN0b3JlRGF0YSkge1xyXG4gICAgICBsb2NhbFN0b3JhZ2Uuc2V0SXRlbSgnbmFtZScsIG5hbWUpO1xyXG4gICAgICBsb2NhbFN0b3JhZ2Uuc2V0SXRlbSgnZW1haWwnLCBlbWFpbCk7XHJcbiAgICB9IGVsc2Uge1xyXG4gICAgICBsb2NhbFN0b3JhZ2UucmVtb3ZlSXRlbSgnbmFtZScpO1xyXG4gICAgICBsb2NhbFN0b3JhZ2UucmVtb3ZlSXRlbSgnZW1haWwnKTtcclxuICAgIH1cclxuXHJcbiAgICBzdWJtaXRDb21tZW50KGNvbW1lbnRPYmopXHJcbiAgICAgIC50aGVuKChyZXMpID0+IHtcclxuICAgICAgICBpZiAocmVzLmNyZWF0ZUNvbW1lbnQpIHtcclxuICAgICAgICAgIGlmICghc3RvcmVEYXRhKSB7XHJcbiAgICAgICAgICAgIGZvcm1EYXRhLm5hbWUgPSAnJztcclxuICAgICAgICAgICAgZm9ybURhdGEuZW1haWwgPSAnJztcclxuICAgICAgICAgIH1cclxuICAgICAgICAgIGZvcm1EYXRhLmNvbW1lbnQgPSAnJztcclxuICAgICAgICAgIHNldEZvcm1EYXRhKChwcmV2U3RhdGUpID0+ICh7XHJcbiAgICAgICAgICAgIC4uLnByZXZTdGF0ZSxcclxuICAgICAgICAgICAgLi4uZm9ybURhdGEsXHJcbiAgICAgICAgICB9KSk7XHJcbiAgICAgICAgICBzZXRTaG93U3VjY2Vzc01lc3NhZ2UodHJ1ZSk7XHJcbiAgICAgICAgICBzZXRUaW1lb3V0KCgpID0+IHtcclxuICAgICAgICAgICAgc2V0U2hvd1N1Y2Nlc3NNZXNzYWdlKGZhbHNlKTtcclxuICAgICAgICAgIH0sIDMwMDApO1xyXG4gICAgICAgIH1cclxuICAgICAgfSk7XHJcbiAgfTtcclxuXHJcbiAgcmV0dXJuIChcclxuICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctd2hpdGUgc2hhZG93LWxnIHJvdW5kZWQtbGcgcC04IHBiLTEyIG1iLThcIj5cclxuICAgICAgPGgzIGNsYXNzTmFtZT1cInRleHQteGwgbWItOCBmb250LXNlbWlib2xkIGJvcmRlci1iIHBiLTRcIj5MZWF2ZSBhIFJlcGx5PC9oMz5cclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0xIGdhcC00IG1iLTRcIj5cclxuICAgICAgICA8dGV4dGFyZWEgdmFsdWU9e2Zvcm1EYXRhLmNvbW1lbnR9IG9uQ2hhbmdlPXtvbklucHV0Q2hhbmdlfSBjbGFzc05hbWU9XCJwLTQgb3V0bGluZS1ub25lIHctZnVsbCByb3VuZGVkLWxnIGgtNDAgZm9jdXM6cmluZy0yIGZvY3VzOnJpbmctZ3JheS0yMDAgYmctZ3JheS0xMDAgdGV4dC1ncmF5LTcwMFwiIG5hbWU9XCJjb21tZW50XCIgcGxhY2Vob2xkZXI9XCJDb21tZW50XCIgLz5cclxuICAgICAgPC9kaXY+XHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMSBsZzpncmlkLWNvbHMtMiBnYXAtNCBtYi00XCI+XHJcbiAgICAgICAgPGlucHV0IHR5cGU9XCJ0ZXh0XCIgdmFsdWU9e2Zvcm1EYXRhLm5hbWV9IG9uQ2hhbmdlPXtvbklucHV0Q2hhbmdlfSBjbGFzc05hbWU9XCJweS0yIHB4LTQgb3V0bGluZS1ub25lIHctZnVsbCByb3VuZGVkLWxnIGZvY3VzOnJpbmctMiBmb2N1czpyaW5nLWdyYXktMjAwIGJnLWdyYXktMTAwIHRleHQtZ3JheS03MDBcIiBwbGFjZWhvbGRlcj1cIk5hbWVcIiBuYW1lPVwibmFtZVwiIC8+XHJcbiAgICAgICAgPGlucHV0IHR5cGU9XCJlbWFpbFwiIHZhbHVlPXtmb3JtRGF0YS5lbWFpbH0gb25DaGFuZ2U9e29uSW5wdXRDaGFuZ2V9IGNsYXNzTmFtZT1cInB5LTIgcHgtNCBvdXRsaW5lLW5vbmUgdy1mdWxsIHJvdW5kZWQtbGcgZm9jdXM6cmluZy0yIGZvY3VzOnJpbmctZ3JheS0yMDAgYmctZ3JheS0xMDAgdGV4dC1ncmF5LTcwMFwiIHBsYWNlaG9sZGVyPVwiRW1haWxcIiBuYW1lPVwiZW1haWxcIiAvPlxyXG4gICAgICA8L2Rpdj5cclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0xIGdhcC00IG1iLTRcIj5cclxuICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgPGlucHV0IGNoZWNrZWQ9e2Zvcm1EYXRhLnN0b3JlRGF0YX0gb25DaGFuZ2U9e29uSW5wdXRDaGFuZ2V9IHR5cGU9XCJjaGVja2JveFwiIGlkPVwic3RvcmVEYXRhXCIgbmFtZT1cInN0b3JlRGF0YVwiIHZhbHVlPVwidHJ1ZVwiIC8+XHJcbiAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwidGV4dC1ncmF5LTUwMCBjdXJzb3ItcG9pbnRlclwiIGh0bWxGb3I9XCJzdG9yZURhdGFcIj4gU2F2ZSBteSBuYW1lLCBlbWFpbCBpbiB0aGlzIGJyb3dzZXIgZm9yIHRoZSBuZXh0IHRpbWUgSSBjb21tZW50LjwvbGFiZWw+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgIDwvZGl2PlxyXG4gICAgICB7ZXJyb3IgJiYgPHAgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LXJlZC01MDBcIj5BbGwgZmllbGRzIGFyZSBtYW5kYXRvcnk8L3A+fVxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LThcIj5cclxuICAgICAgICA8YnV0dG9uIHR5cGU9XCJidXR0b25cIiBvbkNsaWNrPXtoYW5kbGVQb3N0U3VibWlzc2lvbn0gY2xhc3NOYW1lPVwidHJhbnNpdGlvbiBkdXJhdGlvbi01MDAgZWFzZSBob3ZlcjpiZy1pbmRpZ28tOTAwIGlubGluZS1ibG9jayBiZy1waW5rLTYwMCB0ZXh0LWxnIGZvbnQtbWVkaXVtIHJvdW5kZWQtZnVsbCB0ZXh0LXdoaXRlIHB4LTggcHktMyBjdXJzb3ItcG9pbnRlclwiPlBvc3QgQ29tbWVudDwvYnV0dG9uPlxyXG4gICAgICAgIHtzaG93U3VjY2Vzc01lc3NhZ2UgJiYgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC14bCBmbG9hdC1yaWdodCBmb250LXNlbWlib2xkIG10LTMgdGV4dC1ncmVlbi01MDBcIj5Db21tZW50IHN1Ym1pdHRlZCBmb3IgcmV2aWV3PC9zcGFuPn1cclxuICAgICAgPC9kaXY+XHJcbiAgICA8L2Rpdj5cclxuICApO1xyXG59O1xyXG5cclxuZXhwb3J0IGRlZmF1bHQgQ29tbWVudHNGb3JtO1xyXG4iXSwibmFtZXMiOlsiUmVhY3QiLCJ1c2VTdGF0ZSIsInVzZUVmZmVjdCIsInN1Ym1pdENvbW1lbnQiLCJDb21tZW50c0Zvcm0iLCJzbHVnIiwiZXJyb3IiLCJzZXRFcnJvciIsImxvY2FsU3RvcmFnZSIsInNldExvY2FsU3RvcmFnZSIsInNob3dTdWNjZXNzTWVzc2FnZSIsInNldFNob3dTdWNjZXNzTWVzc2FnZSIsIm5hbWUiLCJlbWFpbCIsImNvbW1lbnQiLCJzdG9yZURhdGEiLCJmb3JtRGF0YSIsInNldEZvcm1EYXRhIiwid2luZG93IiwiaW5pdGFsRm9ybURhdGEiLCJnZXRJdGVtIiwib25JbnB1dENoYW5nZSIsImUiLCJ0YXJnZXQiLCJ0eXBlIiwicHJldlN0YXRlIiwiY2hlY2tlZCIsInZhbHVlIiwiaGFuZGxlUG9zdFN1Ym1pc3Npb24iLCJjb21tZW50T2JqIiwic2V0SXRlbSIsInJlbW92ZUl0ZW0iLCJ0aGVuIiwicmVzIiwiY3JlYXRlQ29tbWVudCIsInNldFRpbWVvdXQiXSwic291cmNlUm9vdCI6IiJ9