"use strict";
self["webpackHotUpdate_N_E"]("pages/index",{

/***/ "./components/CommentsForm.jsx":
/*!*************************************!*\
  !*** ./components/CommentsForm.jsx ***!
  \*************************************/
/***/ (function(module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony import */ var C_Users_privy_Desktop_project_graphql_blog_node_modules_babel_runtime_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/defineProperty */ "./node_modules/@babel/runtime/helpers/esm/defineProperty.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _services__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../services */ "./services/index.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! react/jsx-dev-runtime */ "./node_modules/react/jsx-dev-runtime.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__);
/* module decorator */ module = __webpack_require__.hmd(module);


var _jsxFileName = "C:\\Users\\privy\\Desktop\\project_graphql_blog\\components\\CommentsForm.jsx",
    _this = undefined,
    _s = $RefreshSig$();

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { (0,C_Users_privy_Desktop_project_graphql_blog_node_modules_babel_runtime_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_0__.default)(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }





var CommentsForm = function CommentsForm(_ref) {
  _s();

  var slug = _ref.slug;

  var _useState = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false),
      error = _useState[0],
      setError = _useState[1];

  var _useState2 = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(null),
      localStorage = _useState2[0],
      setLocalStorage = _useState2[1];

  var _useState3 = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false),
      showSuccessMessage = _useState3[0],
      setShowSuccessMessage = _useState3[1];

  var _useState4 = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)({
    name: null,
    email: null,
    comment: null,
    storeData: false
  }),
      formData = _useState4[0],
      setFormData = _useState4[1];

  (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(function () {
    setLocalStorage(window.localStorage);
    var initalFormData = {
      name: window.localStorage.getItem('name'),
      email: window.localStorage.getItem('email'),
      storeData: window.localStorage.getItem('name') || window.localStorage.getItem('email')
    };
    setFormData(initalFormData);
  }, []);

  var onInputChange = function onInputChange(e) {
    var target = e.target;

    if (target.type === 'checkbox') {
      setFormData(function (prevState) {
        return _objectSpread(_objectSpread({}, prevState), {}, (0,C_Users_privy_Desktop_project_graphql_blog_node_modules_babel_runtime_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_0__.default)({}, target.name, target.checked));
      });
    } else {
      setFormData(function (prevState) {
        return _objectSpread(_objectSpread({}, prevState), {}, (0,C_Users_privy_Desktop_project_graphql_blog_node_modules_babel_runtime_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_0__.default)({}, target.name, target.value));
      });
    }
  };

  var handlePostSubmission = function handlePostSubmission() {
    setError(false);
    var name = formData.name,
        email = formData.email,
        comment = formData.comment,
        storeData = formData.storeData;

    if (!name || !email || !comment) {
      setError(true);
      return;
    }

    var commentObj = {
      name: name,
      email: email,
      comment: comment,
      slug: slug
    };

    if (storeData) {
      localStorage.setItem('name', name);
      localStorage.setItem('email', email);
    } else {
      localStorage.removeItem('name');
      localStorage.removeItem('email');
    }

    (0,_services__WEBPACK_IMPORTED_MODULE_2__.submitComment)(commentObj).then(function (res) {
      if (res.createComment) {
        if (!storeData) {
          formData.name = '';
          formData.email = '';
        }

        formData.comment = '';
        setFormData(function (prevState) {
          return _objectSpread(_objectSpread({}, prevState), formData);
        });
        setShowSuccessMessage(true);
        setTimeout(function () {
          setShowSuccessMessage(false);
        }, 3000);
      }
    });
  };

  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)("div", {
    className: "bg-white shadow-lg rounded-lg p-8 pb-12 mb-8",
    children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)("h3", {
      className: "text-xl mb-8 font-semibold border-b pb-4",
      children: "Leave a Reply"
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 79,
      columnNumber: 7
    }, _this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)("div", {
      className: "grid grid-cols-1 gap-4 mb-4",
      children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)("textarea", {
        value: formData.comment,
        onChange: onInputChange,
        className: "p-4 outline-none w-full rounded-lg h-40 focus:ring-2 focus:ring-gray-200 bg-gray-100 text-gray-700",
        name: "comment",
        placeholder: "Comment"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 81,
        columnNumber: 9
      }, _this)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 80,
      columnNumber: 7
    }, _this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)("div", {
      className: "grid grid-cols-1 lg:grid-cols-2 gap-4 mb-4",
      children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)("input", {
        type: "text",
        value: formData.name,
        onChange: onInputChange,
        className: "py-2 px-4 outline-none w-full rounded-lg focus:ring-2 focus:ring-gray-200 bg-gray-100 text-gray-700",
        placeholder: "Name",
        name: "name"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 84,
        columnNumber: 9
      }, _this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)("input", {
        type: "email",
        value: formData.email,
        onChange: onInputChange,
        className: "py-2 px-4 outline-none w-full rounded-lg focus:ring-2 focus:ring-gray-200 bg-gray-100 text-gray-700",
        placeholder: "Email",
        name: "email"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 85,
        columnNumber: 9
      }, _this)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 83,
      columnNumber: 7
    }, _this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)("div", {
      className: "grid grid-cols-1 gap-4 mb-4",
      children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)("div", {
        children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)("input", {
          checked: formData.storeData,
          onChange: onInputChange,
          type: "checkbox",
          id: "storeData",
          name: "storeData",
          value: "true"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 89,
          columnNumber: 11
        }, _this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)("label", {
          className: "text-gray-500 cursor-pointer",
          htmlFor: "storeData",
          children: " Save my name, email in this browser for the next time I comment."
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 90,
          columnNumber: 11
        }, _this)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 88,
        columnNumber: 9
      }, _this)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 87,
      columnNumber: 7
    }, _this), error && /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)("p", {
      className: "text-xs text-red-500",
      children: "All fields are mandatory"
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 93,
      columnNumber: 17
    }, _this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)("div", {
      className: "mt-8",
      children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)("button", {
        type: "button",
        onClick: handlePostSubmission,
        className: "transition duration-500 ease hover:bg-indigo-900 inline-block bg-pink-600 text-lg font-medium rounded-full text-white px-8 py-3 cursor-pointer",
        children: "Post Comment"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 95,
        columnNumber: 9
      }, _this), showSuccessMessage && /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)("span", {
        className: "text-xl float-right font-semibold mt-3 text-green-500",
        children: "Comment submitted for review"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 96,
        columnNumber: 32
      }, _this)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 94,
      columnNumber: 7
    }, _this)]
  }, void 0, true, {
    fileName: _jsxFileName,
    lineNumber: 78,
    columnNumber: 5
  }, _this);
};

_s(CommentsForm, "BA55RLdfzQTr8M6BJ3vnJjjiAlM=");

_c = CommentsForm;
/* harmony default export */ __webpack_exports__["default"] = (CommentsForm);

var _c;

$RefreshReg$(_c, "CommentsForm");

;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.id);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }


/***/ })

});
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic3RhdGljL3dlYnBhY2svcGFnZXMvaW5kZXguYWQ5ZTU4YmZhMzBhNjE2ZjJiMjAuaG90LXVwZGF0ZS5qcyIsIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQTtBQUNBOzs7QUFFQSxJQUFNSSxZQUFZLEdBQUcsU0FBZkEsWUFBZSxPQUFjO0FBQUE7O0FBQUEsTUFBWEMsSUFBVyxRQUFYQSxJQUFXOztBQUNqQyxrQkFBMEJKLCtDQUFRLENBQUMsS0FBRCxDQUFsQztBQUFBLE1BQU9LLEtBQVA7QUFBQSxNQUFjQyxRQUFkOztBQUNBLG1CQUF3Q04sK0NBQVEsQ0FBQyxJQUFELENBQWhEO0FBQUEsTUFBT08sWUFBUDtBQUFBLE1BQXFCQyxlQUFyQjs7QUFDQSxtQkFBb0RSLCtDQUFRLENBQUMsS0FBRCxDQUE1RDtBQUFBLE1BQU9TLGtCQUFQO0FBQUEsTUFBMkJDLHFCQUEzQjs7QUFDQSxtQkFBZ0NWLCtDQUFRLENBQUM7QUFBRVcsSUFBQUEsSUFBSSxFQUFFLElBQVI7QUFBY0MsSUFBQUEsS0FBSyxFQUFFLElBQXJCO0FBQTJCQyxJQUFBQSxPQUFPLEVBQUUsSUFBcEM7QUFBMENDLElBQUFBLFNBQVMsRUFBRTtBQUFyRCxHQUFELENBQXhDO0FBQUEsTUFBT0MsUUFBUDtBQUFBLE1BQWlCQyxXQUFqQjs7QUFFQWYsRUFBQUEsZ0RBQVMsQ0FBQyxZQUFNO0FBQ2RPLElBQUFBLGVBQWUsQ0FBQ1MsTUFBTSxDQUFDVixZQUFSLENBQWY7QUFDQSxRQUFNVyxjQUFjLEdBQUc7QUFDckJQLE1BQUFBLElBQUksRUFBRU0sTUFBTSxDQUFDVixZQUFQLENBQW9CWSxPQUFwQixDQUE0QixNQUE1QixDQURlO0FBRXJCUCxNQUFBQSxLQUFLLEVBQUVLLE1BQU0sQ0FBQ1YsWUFBUCxDQUFvQlksT0FBcEIsQ0FBNEIsT0FBNUIsQ0FGYztBQUdyQkwsTUFBQUEsU0FBUyxFQUFFRyxNQUFNLENBQUNWLFlBQVAsQ0FBb0JZLE9BQXBCLENBQTRCLE1BQTVCLEtBQXVDRixNQUFNLENBQUNWLFlBQVAsQ0FBb0JZLE9BQXBCLENBQTRCLE9BQTVCO0FBSDdCLEtBQXZCO0FBS0FILElBQUFBLFdBQVcsQ0FBQ0UsY0FBRCxDQUFYO0FBQ0QsR0FSUSxFQVFOLEVBUk0sQ0FBVDs7QUFVQSxNQUFNRSxhQUFhLEdBQUcsU0FBaEJBLGFBQWdCLENBQUNDLENBQUQsRUFBTztBQUMzQixRQUFRQyxNQUFSLEdBQW1CRCxDQUFuQixDQUFRQyxNQUFSOztBQUNBLFFBQUlBLE1BQU0sQ0FBQ0MsSUFBUCxLQUFnQixVQUFwQixFQUFnQztBQUM5QlAsTUFBQUEsV0FBVyxDQUFDLFVBQUNRLFNBQUQ7QUFBQSwrQ0FDUEEsU0FETyxxSkFFVEYsTUFBTSxDQUFDWCxJQUZFLEVBRUtXLE1BQU0sQ0FBQ0csT0FGWjtBQUFBLE9BQUQsQ0FBWDtBQUlELEtBTEQsTUFLTztBQUNMVCxNQUFBQSxXQUFXLENBQUMsVUFBQ1EsU0FBRDtBQUFBLCtDQUNQQSxTQURPLHFKQUVURixNQUFNLENBQUNYLElBRkUsRUFFS1csTUFBTSxDQUFDSSxLQUZaO0FBQUEsT0FBRCxDQUFYO0FBSUQ7QUFDRixHQWJEOztBQWVBLE1BQU1DLG9CQUFvQixHQUFHLFNBQXZCQSxvQkFBdUIsR0FBTTtBQUNqQ3JCLElBQUFBLFFBQVEsQ0FBQyxLQUFELENBQVI7QUFDQSxRQUFRSyxJQUFSLEdBQTRDSSxRQUE1QyxDQUFRSixJQUFSO0FBQUEsUUFBY0MsS0FBZCxHQUE0Q0csUUFBNUMsQ0FBY0gsS0FBZDtBQUFBLFFBQXFCQyxPQUFyQixHQUE0Q0UsUUFBNUMsQ0FBcUJGLE9BQXJCO0FBQUEsUUFBOEJDLFNBQTlCLEdBQTRDQyxRQUE1QyxDQUE4QkQsU0FBOUI7O0FBQ0EsUUFBSSxDQUFDSCxJQUFELElBQVMsQ0FBQ0MsS0FBVixJQUFtQixDQUFDQyxPQUF4QixFQUFpQztBQUMvQlAsTUFBQUEsUUFBUSxDQUFDLElBQUQsQ0FBUjtBQUNBO0FBQ0Q7O0FBQ0QsUUFBTXNCLFVBQVUsR0FBRztBQUNqQmpCLE1BQUFBLElBQUksRUFBSkEsSUFEaUI7QUFFakJDLE1BQUFBLEtBQUssRUFBTEEsS0FGaUI7QUFHakJDLE1BQUFBLE9BQU8sRUFBUEEsT0FIaUI7QUFJakJULE1BQUFBLElBQUksRUFBSkE7QUFKaUIsS0FBbkI7O0FBT0EsUUFBSVUsU0FBSixFQUFlO0FBQ2JQLE1BQUFBLFlBQVksQ0FBQ3NCLE9BQWIsQ0FBcUIsTUFBckIsRUFBNkJsQixJQUE3QjtBQUNBSixNQUFBQSxZQUFZLENBQUNzQixPQUFiLENBQXFCLE9BQXJCLEVBQThCakIsS0FBOUI7QUFDRCxLQUhELE1BR087QUFDTEwsTUFBQUEsWUFBWSxDQUFDdUIsVUFBYixDQUF3QixNQUF4QjtBQUNBdkIsTUFBQUEsWUFBWSxDQUFDdUIsVUFBYixDQUF3QixPQUF4QjtBQUNEOztBQUVENUIsSUFBQUEsd0RBQWEsQ0FBQzBCLFVBQUQsQ0FBYixDQUNHRyxJQURILENBQ1EsVUFBQ0MsR0FBRCxFQUFTO0FBQ2IsVUFBSUEsR0FBRyxDQUFDQyxhQUFSLEVBQXVCO0FBQ3JCLFlBQUksQ0FBQ25CLFNBQUwsRUFBZ0I7QUFDZEMsVUFBQUEsUUFBUSxDQUFDSixJQUFULEdBQWdCLEVBQWhCO0FBQ0FJLFVBQUFBLFFBQVEsQ0FBQ0gsS0FBVCxHQUFpQixFQUFqQjtBQUNEOztBQUNERyxRQUFBQSxRQUFRLENBQUNGLE9BQVQsR0FBbUIsRUFBbkI7QUFDQUcsUUFBQUEsV0FBVyxDQUFDLFVBQUNRLFNBQUQ7QUFBQSxpREFDUEEsU0FETyxHQUVQVCxRQUZPO0FBQUEsU0FBRCxDQUFYO0FBSUFMLFFBQUFBLHFCQUFxQixDQUFDLElBQUQsQ0FBckI7QUFDQXdCLFFBQUFBLFVBQVUsQ0FBQyxZQUFNO0FBQ2Z4QixVQUFBQSxxQkFBcUIsQ0FBQyxLQUFELENBQXJCO0FBQ0QsU0FGUyxFQUVQLElBRk8sQ0FBVjtBQUdEO0FBQ0YsS0FqQkg7QUFrQkQsR0F4Q0Q7O0FBMENBLHNCQUNFO0FBQUssYUFBUyxFQUFDLDhDQUFmO0FBQUEsNEJBQ0U7QUFBSSxlQUFTLEVBQUMsMENBQWQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFERixlQUVFO0FBQUssZUFBUyxFQUFDLDZCQUFmO0FBQUEsNkJBQ0U7QUFBVSxhQUFLLEVBQUVLLFFBQVEsQ0FBQ0YsT0FBMUI7QUFBbUMsZ0JBQVEsRUFBRU8sYUFBN0M7QUFBNEQsaUJBQVMsRUFBQyxvR0FBdEU7QUFBMkssWUFBSSxFQUFDLFNBQWhMO0FBQTBMLG1CQUFXLEVBQUM7QUFBdE07QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFGRixlQUtFO0FBQUssZUFBUyxFQUFDLDRDQUFmO0FBQUEsOEJBQ0U7QUFBTyxZQUFJLEVBQUMsTUFBWjtBQUFtQixhQUFLLEVBQUVMLFFBQVEsQ0FBQ0osSUFBbkM7QUFBeUMsZ0JBQVEsRUFBRVMsYUFBbkQ7QUFBa0UsaUJBQVMsRUFBQyxxR0FBNUU7QUFBa0wsbUJBQVcsRUFBQyxNQUE5TDtBQUFxTSxZQUFJLEVBQUM7QUFBMU07QUFBQTtBQUFBO0FBQUE7QUFBQSxlQURGLGVBRUU7QUFBTyxZQUFJLEVBQUMsT0FBWjtBQUFvQixhQUFLLEVBQUVMLFFBQVEsQ0FBQ0gsS0FBcEM7QUFBMkMsZ0JBQVEsRUFBRVEsYUFBckQ7QUFBb0UsaUJBQVMsRUFBQyxxR0FBOUU7QUFBb0wsbUJBQVcsRUFBQyxPQUFoTTtBQUF3TSxZQUFJLEVBQUM7QUFBN007QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUZGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUxGLGVBU0U7QUFBSyxlQUFTLEVBQUMsNkJBQWY7QUFBQSw2QkFDRTtBQUFBLGdDQUNFO0FBQU8saUJBQU8sRUFBRUwsUUFBUSxDQUFDRCxTQUF6QjtBQUFvQyxrQkFBUSxFQUFFTSxhQUE5QztBQUE2RCxjQUFJLEVBQUMsVUFBbEU7QUFBNkUsWUFBRSxFQUFDLFdBQWhGO0FBQTRGLGNBQUksRUFBQyxXQUFqRztBQUE2RyxlQUFLLEVBQUM7QUFBbkg7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFERixlQUVFO0FBQU8sbUJBQVMsRUFBQyw4QkFBakI7QUFBZ0QsaUJBQU8sRUFBQyxXQUF4RDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFGRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBVEYsRUFlR2YsS0FBSyxpQkFBSTtBQUFHLGVBQVMsRUFBQyxzQkFBYjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQWZaLGVBZ0JFO0FBQUssZUFBUyxFQUFDLE1BQWY7QUFBQSw4QkFDRTtBQUFRLFlBQUksRUFBQyxRQUFiO0FBQXNCLGVBQU8sRUFBRXNCLG9CQUEvQjtBQUFxRCxpQkFBUyxFQUFDLGdKQUEvRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQURGLEVBRUdsQixrQkFBa0IsaUJBQUk7QUFBTSxpQkFBUyxFQUFDLHVEQUFoQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUZ6QjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFoQkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBREY7QUF1QkQsQ0FoR0Q7O0dBQU1OOztLQUFBQTtBQWtHTiwrREFBZUEsWUFBZiIsInNvdXJjZXMiOlsid2VicGFjazovL19OX0UvLi9jb21wb25lbnRzL0NvbW1lbnRzRm9ybS5qc3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFJlYWN0LCB7IHVzZVN0YXRlLCB1c2VFZmZlY3QgfSBmcm9tICdyZWFjdCc7XHJcbmltcG9ydCB7IHN1Ym1pdENvbW1lbnQgfSBmcm9tICcuLi9zZXJ2aWNlcyc7XHJcblxyXG5jb25zdCBDb21tZW50c0Zvcm0gPSAoeyBzbHVnIH0pID0+IHtcclxuICBjb25zdCBbZXJyb3IsIHNldEVycm9yXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICBjb25zdCBbbG9jYWxTdG9yYWdlLCBzZXRMb2NhbFN0b3JhZ2VdID0gdXNlU3RhdGUobnVsbCk7XHJcbiAgY29uc3QgW3Nob3dTdWNjZXNzTWVzc2FnZSwgc2V0U2hvd1N1Y2Nlc3NNZXNzYWdlXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICBjb25zdCBbZm9ybURhdGEsIHNldEZvcm1EYXRhXSA9IHVzZVN0YXRlKHsgbmFtZTogbnVsbCwgZW1haWw6IG51bGwsIGNvbW1lbnQ6IG51bGwsIHN0b3JlRGF0YTogZmFsc2UgfSk7XHJcblxyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBzZXRMb2NhbFN0b3JhZ2Uod2luZG93LmxvY2FsU3RvcmFnZSk7XHJcbiAgICBjb25zdCBpbml0YWxGb3JtRGF0YSA9IHtcclxuICAgICAgbmFtZTogd2luZG93LmxvY2FsU3RvcmFnZS5nZXRJdGVtKCduYW1lJyksXHJcbiAgICAgIGVtYWlsOiB3aW5kb3cubG9jYWxTdG9yYWdlLmdldEl0ZW0oJ2VtYWlsJyksXHJcbiAgICAgIHN0b3JlRGF0YTogd2luZG93LmxvY2FsU3RvcmFnZS5nZXRJdGVtKCduYW1lJykgfHwgd2luZG93LmxvY2FsU3RvcmFnZS5nZXRJdGVtKCdlbWFpbCcpLFxyXG4gICAgfTtcclxuICAgIHNldEZvcm1EYXRhKGluaXRhbEZvcm1EYXRhKTtcclxuICB9LCBbXSk7XHJcblxyXG4gIGNvbnN0IG9uSW5wdXRDaGFuZ2UgPSAoZSkgPT4ge1xyXG4gICAgY29uc3QgeyB0YXJnZXQgfSA9IGU7XHJcbiAgICBpZiAodGFyZ2V0LnR5cGUgPT09ICdjaGVja2JveCcpIHtcclxuICAgICAgc2V0Rm9ybURhdGEoKHByZXZTdGF0ZSkgPT4gKHtcclxuICAgICAgICAuLi5wcmV2U3RhdGUsXHJcbiAgICAgICAgW3RhcmdldC5uYW1lXTogdGFyZ2V0LmNoZWNrZWQsXHJcbiAgICAgIH0pKTtcclxuICAgIH0gZWxzZSB7XHJcbiAgICAgIHNldEZvcm1EYXRhKChwcmV2U3RhdGUpID0+ICh7XHJcbiAgICAgICAgLi4ucHJldlN0YXRlLFxyXG4gICAgICAgIFt0YXJnZXQubmFtZV06IHRhcmdldC52YWx1ZSxcclxuICAgICAgfSkpO1xyXG4gICAgfVxyXG4gIH07XHJcblxyXG4gIGNvbnN0IGhhbmRsZVBvc3RTdWJtaXNzaW9uID0gKCkgPT4ge1xyXG4gICAgc2V0RXJyb3IoZmFsc2UpO1xyXG4gICAgY29uc3QgeyBuYW1lLCBlbWFpbCwgY29tbWVudCwgc3RvcmVEYXRhIH0gPSBmb3JtRGF0YTtcclxuICAgIGlmICghbmFtZSB8fCAhZW1haWwgfHwgIWNvbW1lbnQpIHtcclxuICAgICAgc2V0RXJyb3IodHJ1ZSk7XHJcbiAgICAgIHJldHVybjtcclxuICAgIH1cclxuICAgIGNvbnN0IGNvbW1lbnRPYmogPSB7XHJcbiAgICAgIG5hbWUsXHJcbiAgICAgIGVtYWlsLFxyXG4gICAgICBjb21tZW50LFxyXG4gICAgICBzbHVnLFxyXG4gICAgfTtcclxuXHJcbiAgICBpZiAoc3RvcmVEYXRhKSB7XHJcbiAgICAgIGxvY2FsU3RvcmFnZS5zZXRJdGVtKCduYW1lJywgbmFtZSk7XHJcbiAgICAgIGxvY2FsU3RvcmFnZS5zZXRJdGVtKCdlbWFpbCcsIGVtYWlsKTtcclxuICAgIH0gZWxzZSB7XHJcbiAgICAgIGxvY2FsU3RvcmFnZS5yZW1vdmVJdGVtKCduYW1lJyk7XHJcbiAgICAgIGxvY2FsU3RvcmFnZS5yZW1vdmVJdGVtKCdlbWFpbCcpO1xyXG4gICAgfVxyXG5cclxuICAgIHN1Ym1pdENvbW1lbnQoY29tbWVudE9iailcclxuICAgICAgLnRoZW4oKHJlcykgPT4ge1xyXG4gICAgICAgIGlmIChyZXMuY3JlYXRlQ29tbWVudCkge1xyXG4gICAgICAgICAgaWYgKCFzdG9yZURhdGEpIHtcclxuICAgICAgICAgICAgZm9ybURhdGEubmFtZSA9ICcnO1xyXG4gICAgICAgICAgICBmb3JtRGF0YS5lbWFpbCA9ICcnO1xyXG4gICAgICAgICAgfVxyXG4gICAgICAgICAgZm9ybURhdGEuY29tbWVudCA9ICcnO1xyXG4gICAgICAgICAgc2V0Rm9ybURhdGEoKHByZXZTdGF0ZSkgPT4gKHtcclxuICAgICAgICAgICAgLi4ucHJldlN0YXRlLFxyXG4gICAgICAgICAgICAuLi5mb3JtRGF0YSxcclxuICAgICAgICAgIH0pKTtcclxuICAgICAgICAgIHNldFNob3dTdWNjZXNzTWVzc2FnZSh0cnVlKTtcclxuICAgICAgICAgIHNldFRpbWVvdXQoKCkgPT4ge1xyXG4gICAgICAgICAgICBzZXRTaG93U3VjY2Vzc01lc3NhZ2UoZmFsc2UpO1xyXG4gICAgICAgICAgfSwgMzAwMCk7XHJcbiAgICAgICAgfVxyXG4gICAgICB9KTtcclxuICB9O1xyXG5cclxuICByZXR1cm4gKFxyXG4gICAgPGRpdiBjbGFzc05hbWU9XCJiZy13aGl0ZSBzaGFkb3ctbGcgcm91bmRlZC1sZyBwLTggcGItMTIgbWItOFwiPlxyXG4gICAgICA8aDMgY2xhc3NOYW1lPVwidGV4dC14bCBtYi04IGZvbnQtc2VtaWJvbGQgYm9yZGVyLWIgcGItNFwiPkxlYXZlIGEgUmVwbHk8L2gzPlxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTEgZ2FwLTQgbWItNFwiPlxyXG4gICAgICAgIDx0ZXh0YXJlYSB2YWx1ZT17Zm9ybURhdGEuY29tbWVudH0gb25DaGFuZ2U9e29uSW5wdXRDaGFuZ2V9IGNsYXNzTmFtZT1cInAtNCBvdXRsaW5lLW5vbmUgdy1mdWxsIHJvdW5kZWQtbGcgaC00MCBmb2N1czpyaW5nLTIgZm9jdXM6cmluZy1ncmF5LTIwMCBiZy1ncmF5LTEwMCB0ZXh0LWdyYXktNzAwXCIgbmFtZT1cImNvbW1lbnRcIiBwbGFjZWhvbGRlcj1cIkNvbW1lbnRcIiAvPlxyXG4gICAgICA8L2Rpdj5cclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0xIGxnOmdyaWQtY29scy0yIGdhcC00IG1iLTRcIj5cclxuICAgICAgICA8aW5wdXQgdHlwZT1cInRleHRcIiB2YWx1ZT17Zm9ybURhdGEubmFtZX0gb25DaGFuZ2U9e29uSW5wdXRDaGFuZ2V9IGNsYXNzTmFtZT1cInB5LTIgcHgtNCBvdXRsaW5lLW5vbmUgdy1mdWxsIHJvdW5kZWQtbGcgZm9jdXM6cmluZy0yIGZvY3VzOnJpbmctZ3JheS0yMDAgYmctZ3JheS0xMDAgdGV4dC1ncmF5LTcwMFwiIHBsYWNlaG9sZGVyPVwiTmFtZVwiIG5hbWU9XCJuYW1lXCIgLz5cclxuICAgICAgICA8aW5wdXQgdHlwZT1cImVtYWlsXCIgdmFsdWU9e2Zvcm1EYXRhLmVtYWlsfSBvbkNoYW5nZT17b25JbnB1dENoYW5nZX0gY2xhc3NOYW1lPVwicHktMiBweC00IG91dGxpbmUtbm9uZSB3LWZ1bGwgcm91bmRlZC1sZyBmb2N1czpyaW5nLTIgZm9jdXM6cmluZy1ncmF5LTIwMCBiZy1ncmF5LTEwMCB0ZXh0LWdyYXktNzAwXCIgcGxhY2Vob2xkZXI9XCJFbWFpbFwiIG5hbWU9XCJlbWFpbFwiIC8+XHJcbiAgICAgIDwvZGl2PlxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTEgZ2FwLTQgbWItNFwiPlxyXG4gICAgICAgIDxkaXY+XHJcbiAgICAgICAgICA8aW5wdXQgY2hlY2tlZD17Zm9ybURhdGEuc3RvcmVEYXRhfSBvbkNoYW5nZT17b25JbnB1dENoYW5nZX0gdHlwZT1cImNoZWNrYm94XCIgaWQ9XCJzdG9yZURhdGFcIiBuYW1lPVwic3RvcmVEYXRhXCIgdmFsdWU9XCJ0cnVlXCIgLz5cclxuICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJ0ZXh0LWdyYXktNTAwIGN1cnNvci1wb2ludGVyXCIgaHRtbEZvcj1cInN0b3JlRGF0YVwiPiBTYXZlIG15IG5hbWUsIGVtYWlsIGluIHRoaXMgYnJvd3NlciBmb3IgdGhlIG5leHQgdGltZSBJIGNvbW1lbnQuPC9sYWJlbD5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgPC9kaXY+XHJcbiAgICAgIHtlcnJvciAmJiA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtcmVkLTUwMFwiPkFsbCBmaWVsZHMgYXJlIG1hbmRhdG9yeTwvcD59XHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtOFwiPlxyXG4gICAgICAgIDxidXR0b24gdHlwZT1cImJ1dHRvblwiIG9uQ2xpY2s9e2hhbmRsZVBvc3RTdWJtaXNzaW9ufSBjbGFzc05hbWU9XCJ0cmFuc2l0aW9uIGR1cmF0aW9uLTUwMCBlYXNlIGhvdmVyOmJnLWluZGlnby05MDAgaW5saW5lLWJsb2NrIGJnLXBpbmstNjAwIHRleHQtbGcgZm9udC1tZWRpdW0gcm91bmRlZC1mdWxsIHRleHQtd2hpdGUgcHgtOCBweS0zIGN1cnNvci1wb2ludGVyXCI+UG9zdCBDb21tZW50PC9idXR0b24+XHJcbiAgICAgICAge3Nob3dTdWNjZXNzTWVzc2FnZSAmJiA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXhsIGZsb2F0LXJpZ2h0IGZvbnQtc2VtaWJvbGQgbXQtMyB0ZXh0LWdyZWVuLTUwMFwiPkNvbW1lbnQgc3VibWl0dGVkIGZvciByZXZpZXc8L3NwYW4+fVxyXG4gICAgICA8L2Rpdj5cclxuICAgIDwvZGl2PlxyXG4gICk7XHJcbn07XHJcblxyXG5leHBvcnQgZGVmYXVsdCBDb21tZW50c0Zvcm07XHJcbiJdLCJuYW1lcyI6WyJSZWFjdCIsInVzZVN0YXRlIiwidXNlRWZmZWN0Iiwic3VibWl0Q29tbWVudCIsIkNvbW1lbnRzRm9ybSIsInNsdWciLCJlcnJvciIsInNldEVycm9yIiwibG9jYWxTdG9yYWdlIiwic2V0TG9jYWxTdG9yYWdlIiwic2hvd1N1Y2Nlc3NNZXNzYWdlIiwic2V0U2hvd1N1Y2Nlc3NNZXNzYWdlIiwibmFtZSIsImVtYWlsIiwiY29tbWVudCIsInN0b3JlRGF0YSIsImZvcm1EYXRhIiwic2V0Rm9ybURhdGEiLCJ3aW5kb3ciLCJpbml0YWxGb3JtRGF0YSIsImdldEl0ZW0iLCJvbklucHV0Q2hhbmdlIiwiZSIsInRhcmdldCIsInR5cGUiLCJwcmV2U3RhdGUiLCJjaGVja2VkIiwidmFsdWUiLCJoYW5kbGVQb3N0U3VibWlzc2lvbiIsImNvbW1lbnRPYmoiLCJzZXRJdGVtIiwicmVtb3ZlSXRlbSIsInRoZW4iLCJyZXMiLCJjcmVhdGVDb21tZW50Iiwic2V0VGltZW91dCJdLCJzb3VyY2VSb290IjoiIn0=